from flask import Flask, request, jsonify, send_from_directory
from flask_cors import CORS
import os, uuid, json

# ---------- 新增：算法注册中心（★ 若只用 louvain 也能正常跑） ----------
from backend.algo import get_algorithm          # backend/algo/__init__.py 见注释

# ---------- 基础设置 ----------
app = Flask(__name__)
CORS(app, resources={r"/api/*": {"origins": "*"}})


@app.route("/")
def hello():
    return "Flask is working!"


@app.route("/api/hello")
def api_hello():
    return {"msg": "hello world"}


# -------- 上传目录 --------
UPLOAD_DIR = "uploads"
os.makedirs(UPLOAD_DIR, exist_ok=True)           # 没有文件夹就自动创建


# -------- 上传接口 --------
@app.route("/api/upload", methods=["POST"])
def upload():
    """
    前端用 FormData 提交键名 file 的文件：
        例：fetch('/api/upload', {method:'POST', body:formData})
    """
    f = request.files["file"]                    # 取出上传的文件对象
    task_id = uuid.uuid4().hex[:8]               # 生成 8 位短 id
    save_path = os.path.join(UPLOAD_DIR, f"{task_id}.json")
    f.save(save_path)                            # 保存到磁盘

    # ---------- 新增：算法可切换（louvain / leiden …） ----------
    algo_name = request.args.get("algo", "louvain")   # /api/upload?algo=leiden
    algo      = get_algorithm(algo_name)              # ★ 动态获取算法实例
    n_clusters = algo.add_cluster_field(save_path)    # ★ 写入 cluster 字段

    return jsonify({"task_id": task_id, "clusters": n_clusters})


@app.route("/api/graph/<task_id>")
def get_graph(task_id):
    """直接把上传的原始 JSON 发回给前端。"""
    return send_from_directory(UPLOAD_DIR, f"{task_id}.json")


@app.route("/api/stats/<task_id>")
def stats(task_id):
    """读取 JSON，数节点 / 边数量。"""
    fp = os.path.join(UPLOAD_DIR, f"{task_id}.json")
    g  = json.load(open(fp, encoding="utf-8"))
    return {"nodes": len(g["nodes"]), "edges": len(g["edges"])}


if __name__ == "__main__":
    # debug=True 方便热重载；上线请改为生产 WSGI（gunicorn / waitress …）
    app.run(debug=True, host="0.0.0.0", port=5000)

