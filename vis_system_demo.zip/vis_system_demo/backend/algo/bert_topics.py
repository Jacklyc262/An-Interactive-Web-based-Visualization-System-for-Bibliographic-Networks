# ----------------------------------------------------------
#  backend/algo/bert_topics.py
#  保留原注释，只在【★ 标记】处补充 TF-IDF 取簇名逻辑
# ----------------------------------------------------------
import json, numpy as np
from ..utils import normalize_json                 # ← 兜底工具
from sklearn.cluster import KMeans
from sklearn.feature_extraction.text import TfidfVectorizer   # ★ 新
from sentence_transformers import SentenceTransformer


class Algorithm:
    name = "bert_topics"

    def __init__(self,
                 model_name: str = "all-MiniLM-L6-v2",
                 n_clusters: int | None = None):
        # n_clusters=None 时后面会按节点数开方取簇数
        self.model      = SentenceTransformer(model_name)
        self.n_clusters = n_clusters

    # ------------------- 核心入口 -------------------
    def add_cluster_field(self, path, **kwargs):
        """
        给 path 指向的 JSON 加 cluster 字段，返回簇数
        """
        # 1. 载入 + 字段兜底（title→label 回退）
        data   = normalize_json(path)

        # 2. 提取待编码文本
        titles = [n["title"] for n in data["nodes"]]

        # 3. 做 BERT 编码
        emb = self.model.encode(titles, show_progress_bar=False)

        # 4. 决定簇个数：若用户未指定，用 √N
        k = self.n_clusters or max(2, int(np.sqrt(len(titles))))

        # 5. K-Means 聚类
        labels = KMeans(k, random_state=42, n_init="auto").fit_predict(emb)

        # 6. 写回 cluster id
        for n, cid in zip(data["nodes"], labels):
            n["cluster"] = int(cid)

        # ---------- ★ 6.5 通过 TF-IDF 为每个簇自动取名 ----------
        cid2docs: dict[int, list[str]] = {}
        for n in data["nodes"]:
            cid2docs.setdefault(n["cluster"], []).append(n["title"])

        cid2name: dict[int, str] = {}
        for cid, docs in cid2docs.items():
            tfidf = TfidfVectorizer(stop_words="english",
                                    ngram_range=(1, 2),
                                    max_features=4000)
            X   = tfidf.fit_transform(docs)
            idx = X.sum(axis=0).A1.argsort()[::-1][:3]        # top-3 词/短语
            vocab = tfidf.get_feature_names_out()
            cid2name[cid] = ", ".join(vocab[i] for i in idx) or f"Cluster {cid}"

        # topic 字段供前端 Legend / 侧栏使用
        for n in data["nodes"]:
            n["topic"] = cid2name[n["cluster"]]
        # ---------- ★ TF-IDF 取名结束 ----------

        # 7. 保存
        with open(path, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)

        return k



