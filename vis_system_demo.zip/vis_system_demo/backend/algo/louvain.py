import json, networkx as nx
from networkx.algorithms.community import louvain_communities

class Algorithm:
    name = "louvain"

    def add_cluster_field(self, path, **kw):
        """给 path 指向的 JSON 加 cluster 字段，返回簇数量"""
        with open(path, 'r', encoding='utf-8') as f:
            data = json.load(f)

        G = nx.Graph()
        G.add_nodes_from([n['id'] for n in data['nodes']])
        G.add_edges_from([(e['source'], e['target']) for e in data['edges']])

        comms = louvain_communities(G, **kw)          # ★ 真正的算法
        for cid, comm in enumerate(comms):
            for nid in comm:
                next(n for n in data['nodes'] if n['id']==nid)['cluster'] = cid

        with open(path, 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False)

        return len(comms)
