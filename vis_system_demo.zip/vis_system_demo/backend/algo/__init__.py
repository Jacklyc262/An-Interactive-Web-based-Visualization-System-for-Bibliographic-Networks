from importlib import import_module

# 注册所有算法；以后加文件只需把名字放进数组
for name in ["louvain", "bert_topics"]:
    mod = import_module(f".{name}", package=__name__)
    globals()[name] = mod.Algorithm()

def get_algorithm(name: str):
    return globals().get(name, louvain)   # 默认 louvain
