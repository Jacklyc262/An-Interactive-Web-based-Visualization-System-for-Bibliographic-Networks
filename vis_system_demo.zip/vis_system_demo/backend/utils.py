"""
backend/utils.py
------------------------------------------------------------------
统一“读 JSON”与“字段兜底”的小工具。允许：
    • 传入   路径(str / Path)   → 读取磁盘文件
    • 传入   dict               → 原样返回，但补缺省字段
"""

import json
import pathlib
from typing import Union, Dict

__all__ = ["normalize_json"]


def _patch_fields(data: Dict) -> Dict:
    """
    确保每个节点至少有 id / title / label
    - 若无 title → 用 label 补
    - 若无 label → 设空串
    """
    for n in data.get("nodes", []):
        if "title" not in n or not n["title"]:
            n["title"] = n.get("label", "")
        n.setdefault("label", "")
    return data


def normalize_json(obj: Union[str, pathlib.Path, Dict]) -> Dict:
    """
    既可接收路径，也可直接接收已加载的 dict
    """
    if isinstance(obj, (str, pathlib.Path)):
        data = json.load(open(obj, encoding="utf-8"))
    else:  # 已是 dict
        data = obj
    return _patch_fields(data)

