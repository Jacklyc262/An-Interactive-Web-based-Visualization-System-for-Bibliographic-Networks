// main.js（完整替换）
/* ----------------------------------------------------------
 *  Graph Vis Demo – main.js
 *  保留原注释，只在 ★ 标记处作补丁
 * ---------------------------------------------------------- */

import cytoscape from "cytoscape";
import cise      from "cytoscape-cise";           // ★ cluster-aware 布局
cytoscape.use(cise);
import fcose     from "cytoscape-fcose";          // ★ fCoSE
cytoscape.use(fcose);

const API = "http://127.0.0.1:5000";              // 后端地址
let cy  = null;                                   // Cytoscape 实例（全局存一份）

/* ---------- 调色盘 ---------- */
const colorByCluster = cid =>
  `hsl(${(cid * 137.508) % 360}, 65%, 60%)`;

/* ---------- 1. 上传文件 ---------- */
async function upload(file) {
  const fd = new FormData();
  fd.append("file", file);
  const res = await fetch(`${API}/api/upload?algo=${document.getElementById("algo").value}`, { method: "POST", body: fd });
  const { task_id } = await res.json();
  return task_id;
}

/* ---------- 2. 拉取 JSON 与统计 ---------- */
const fetchGraph = id  => fetch(`${API}/api/graph/${id}`).then(r => r.json());
const fetchStats = id  => fetch(`${API}/api/stats/${id}`).then(r => r.json());

/* ---------- 全局数据索引（派生关系/簇摘要/折叠状态） ---------- */
let originalGraph = null;                 // 服务端返回的原始 nodes/edges
let derivedEdges  = null;                 // {citation:[], cocitation:[], coupling:[]}
let hasYear       = false;                // 是否存在 year 字段
let collapsed     = false;                // 是否全局折叠
const collapsedClusters = new Set();      // 被折叠的簇 id 集合
let lastPicked = [];                      // 最近点击的两个节点用于找路
let clusterIndex = null;                  // 簇摘要索引 Map<number, {...}>

/* ★ 渐进式探索：已钉住节点集合（id） */
const pinned = new Set();
/* ★ 路径锁定：最短路后锁交互（悬停/点击），点击空白解除 */
let pathLocked = false;
/* ★ 折叠视图下被选中的簇（保持高亮用） */
let selectedCluster = null;

/* ───── ★ Node Exploration History ───── */
let history = []; // [{id,title,year,topic,cluster, ts}]
let applyPinnedExternal = () => {}; // 供历史点击时触发当前高亮

function escapeHtml(s="") {
  return String(s).replace(/[&<>"]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
}
function addToHistory(d) {
  if (!d || !d.id) return;
  history = history.filter(x => x.id !== d.id);
  history.unshift({
    id: d.id,
    title: d.title || d.label || d.id,
    year: d.year ?? null,
    topic: d.topic || "",
    cluster: d.cluster ?? null,
    ts: Date.now()
  });
  renderHistory();
}
function removeFromHistory(id) { history = history.filter(x => x.id !== id); renderHistory(); }
function clearHistory()       { history = []; renderHistory(); }
function renderHistory() {
  const box = document.getElementById("historyList");
  if (!box) return;

  const isPresent = (id) => cy && cy.getElementById(id).nonempty();
  box.innerHTML = history.map(item => `
    <div class="history-item ${isPresent(item.id) ? "" : "missing"}" data-id="${item.id}">
      <span class="del" title="Remove">×</span>
      <div class="title">${escapeHtml(item.title)}</div>
      <div class="meta">
        ID: ${escapeHtml(item.id)}
        ${item.year ? ` · Year: ${item.year}` : ""} 
        ${item.topic ? ` · ${escapeHtml(item.topic)}` : ""}
      </div>
    </div>
  `).join("");

  // 事件委托：点击卡片=高亮，不缩放；点击 × = 删除
  box.onclick = (e) => {
    const card = e.target.closest(".history-item");
    if (!card) return;
    const id = card.dataset.id;

    if (e.target.closest(".del")) { removeFromHistory(id); return; }

    if (!cy) return;
    const n = cy.getElementById(id);
    if (n.nonempty()) {
      pinned.clear();
      pinned.add(id);
      pathLocked = false;
      selectedCluster = null; // 退出簇选中态

      const d = n.data();
      document.getElementById("info").textContent =
        `ID    : ${d.id}\n` +
        (d.title ?  `Title : ${d.title}\n` : "") +
        (d.label ?  `Label : ${d.label}\n` : "") +
        (d.topic ?  `Topic : ${d.topic}\n` : "") +
        (d.year  ?  `Year  : ${d.year}\n`  : "");
      applyPinnedExternal(); // 只改高亮，不调用 fit/center
    }
  };

  const clearBtn = document.getElementById("historyClearBtn");
  if (clearBtn) clearBtn.onclick = clearHistory;
}

/* ---------- 关系派生（co-citation / coupling） ---------- */
function buildDerivedEdges(graph) {
  const edges = graph.edges || [];
  const citation = edges.map(e => ({...e}));

  const refsBySrc = new Map();   // s -> Set(t)
  const srcByTgt  = new Map();   // t -> Set(s)
  for (const e of edges) {
    if (!refsBySrc.has(e.source)) refsBySrc.set(e.source, new Set());
    if (!srcByTgt.has(e.target))  srcByTgt.set(e.target , new Set());
    refsBySrc.get(e.source).add(e.target);
    srcByTgt.get(e.target).add(e.source);
  }

  const bump = (map, a, b) => {
    const u = a < b ? a : b, v = a < b ? b : a;
    const key = `${u}|${v}`;
    map.set(key, (map.get(key) || 0) + 1);
  };

  // co-citation：同被某篇 paper 引用的两篇之间连边
  const coCount = new Map();
  for (const [, T] of refsBySrc) {
    const arr = [...T];
    for (let i=0;i<arr.length;i++)
      for (let j=i+1;j<arr.length;j++)
        bump(coCount, arr[i], arr[j]);
  }

  // bibliographic coupling：两篇 paper 共同引用同一批文献
  const bcCount = new Map();
  for (const [, S] of srcByTgt) {
    const arr = [...S];
    for (let i=0;i<arr.length;i++)
      for (let j=i+1;j<arr.length;j++)   // ★ 修复这里的笔误（之前写成 j$arr.length）
        bump(bcCount, arr[i], arr[j]);
  }

  // 转为边，设个阈值（避免爆炸）
  const toEdgeList = (cntMap, min=2, cap=2500) => {
    const out = [];
    for (const [key, w] of cntMap) {
      if (w < min) continue;
      const [u,v] = key.split("|");
      out.push({ source:u, target:v, weight:w });
      if (out.length >= cap) break;
    }
    return out;
  };

  return {
    citation,
    cocitation: toEdgeList(coCount, 2, 2500),
    coupling : toEdgeList(bcCount, 2, 2500),
  };
}

/* ---------- 簇摘要索引（关键词/计数） ---------- */
function buildClusterIndex(graph) {
  const map = new Map(); // cid -> {nodes:[], size, topics[], topTerms[], in,out,intra}

  const tok = s => (s||"")
    .toLowerCase()
    .replace(/[^a-z0-9\s]/g," ")
    .split(/\s+/)
    .filter(w => w.length >= 4 && !stop.has(w));

  const stop = new Set(["with","from","that","this","into","using","data","for","core","text","book","edition","guide","into","your","will","most","some","many","very","into","home","what"]);

  // 初始化
  for (const n of graph.nodes) {
    const c = n.cluster ?? 0;
    if (!map.has(c)) map.set(c, { nodes:[], size:0, topicFreq:new Map(), termFreq:new Map(), in:0, out:0, intra:0 });
    const rec = map.get(c);
    rec.nodes.push(n);
    rec.size++;
    if (n.topic) rec.topicFreq.set(n.topic, (rec.topicFreq.get(n.topic)||0)+1);
    const bag = [].concat(n.title||[], n.label||[], n.topic||[]).join(" ");
    for (const w of tok(bag)) rec.termFreq.set(w, (rec.termFreq.get(w)||0)+1);
  }

  // 边计数
  for (const e of (graph.edges||[])) {
    const su = graph.nodes.find(x=>x.id===e.source)?.cluster ?? -1;
    const tv = graph.nodes.find(x=>x.id===e.target)?.cluster ?? -1;
    if (su<0 || tv<0) continue;
    if (su === tv) map.get(su).intra++;
    else { map.get(su).out++; map.get(tv).in++; }
  }

  // 排序求 top 主题/词
  for (const [, rec] of map) {
    rec.topics   = [...rec.topicFreq.entries()].sort((a,b)=>b[1]-a[1]).slice(0,3).map(x=>x[0]);
    rec.topTerms = [...rec.termFreq.entries()].sort((a,b)=>b[1]-a[1]).slice(0,6).map(x=>x[0]);
  }
  return map;
}

/* ---------- 折叠/展开：把簇替换为 meta-node ---------- */
function makeCollapsedElements(graph) {
  const nodesByCluster = new Map();
  for (const n of graph.nodes) {
    const c = n.cluster ?? 0;
    if (!nodesByCluster.has(c)) nodesByCluster.set(c, []);
    nodesByCluster.get(c).push(n);
  }

  // meta 节点
  const metaNodes = [];
  for (const [c, arr] of nodesByCluster) {
    metaNodes.push({ data:{ id:`cluster:${c}`, cluster:c, size:arr.length, label:`C${c}` } });
  }

  // 簇间边（聚合计数）
  const agg = new Map();
  const bump = (a,b) => {
    const u = a<b ? a:b, v = a<b ? b:a;
    const key = `${u}|${v}`;
    agg.set(key, (agg.get(key)||0)+1);
  };
  for (const e of (graph.edges||[])) {
    const su = graph.nodes.find(x=>x.id===e.source)?.cluster ?? -1;
    const tv = graph.nodes.find(x=>x.id===e.target)?.cluster ?? -1;
    if (su<0 || tv<0 || su===tv) continue;
    bump(`cluster:${su}`, `cluster:${tv}`);
  }
  const metaEdges = [...agg.entries()].map(([key,w],i)=>{
    const [u,v] = key.split("|");
    return { data:{ id:`mc${i}`, source:u, target:v, weight:w } };
  });

  return { nodes:metaNodes, edges:metaEdges };
}

/* ---------- 5. 布局切换（统一函数） ---------- */
const getLayoutOpts = name => {
  if (name === "concentric") {
    return {
      name: "concentric",
      concentric  : e => e.data("cluster"),
      levelWidth  : () => 1,
      minNodeSpacing : 20,
      padding        : 30
    };
  }
  if (name === "cise") {
    return {
      name: "cise",
      clusters: n => n.data("cluster"),
      allowNodesInsideCircle: true,
      animate: false,
      fit: true,
      padding: 50
    };
  }
  if (name === "fcose") {                 // ★ fCoSE：更疏、更清晰的一套参数
    return {
      name: "fcose",
      quality: "default",
      randomize: true,
      fit: true,
      padding: 60,
      animate: false,
      packComponents: true,
      nodeDimensionsIncludeLabels: false,
      nodeSeparation: 70,
      idealEdgeLength: () => 180,
      edgeElasticity: () => 0.15,
      gravity: 0.25,
      gravityRangeCompound: 1.5,
      gravityCompound: 1.0,
      gravityRange: 3.8,
      nestingFactor: 0.8
    };
  }
  return { name };
};

/* ---------- 3. 画图并绑定交互 ---------- */
function draw(graph, relation="citation") {
  if (cy) cy.destroy();                           // 重绘前先销毁

  originalGraph = graph;
  derivedEdges  = buildDerivedEdges(graph);
  clusterIndex  = buildClusterIndex(graph);
  hasYear       = graph.nodes.some(n => n.year != null);
  collapsed     = document.getElementById("chkCollapse").checked;

  // 非 citation 视角：禁用布局选择，强制 fcose；隐藏孤立点
  const layoutSel = document.getElementById("layout");
  const relationSel = document.getElementById("relation");
  const nonCitation = relationSel.value !== "citation";
  layoutSel.disabled = nonCitation;
  const forcedLayout = nonCitation ? "fcose" : layoutSel.value;

  // elements：是否折叠 + 哪种关系
  const relEdges = derivedEdges[relation] || [];

  // 计算度数（过滤孤立点，仅在 co-* 视角）
  const deg = new Map();
  if (nonCitation) {
    for (const e of relEdges) {
      deg.set(e.source, (deg.get(e.source)||0)+1);
      deg.set(e.target, (deg.get(e.target)||0)+1);
    }
  }

  const elements = [];
  if (collapsed) {
    const co = makeCollapsedElements({nodes:graph.nodes, edges:relEdges});
    elements.push(...co.nodes, ...co.edges);
  } else {
    const keptNodes = nonCitation
      ? graph.nodes.filter(n => (deg.get(n.id)||0) > 0)
      : graph.nodes;
    elements.push(
      ...keptNodes.map(n => ({ data:n })),
      ...relEdges.map((e,i)=>({ data:{ id:`e${i}`, ...e }}))
    );
  }

  const layoutOpts = getLayoutOpts(forcedLayout);

  cy = cytoscape({
    container: document.getElementById("cy"),
    elements,
    layout: layoutOpts,

    /* ---------- 样式 ---------- */
    style: [
      { selector:"node", style:{
          label: "", width: collapsed ? "mapData(size, 1, 100, 24, 48)" : 22,
          height: collapsed ? "mapData(size, 1, 100, 24, 48)" : 22,
          "background-color": ele => colorByCluster(ele.data("cluster")),
          "border-width": collapsed ? 2 : 0,
          "border-color": "#333",
          "text-valign": "center",
          "text-halign": "center",
          color:"#000", "font-weight":"bold"
      }},
      { selector:"edge", style:{
          width:1.5,
          "line-color":"#999",
          "opacity":0.65,
          "curve-style":"bezier",
          "target-arrow-shape": "none",
          "arrow-scale":1
      }},
      { selector:".faded",     style:{ opacity:0.12 } },
      { selector:".highlight", style:{ "border-width":3, "border-color":"#222" } },
      { selector:".pathEdge",  style:{ "line-color":"#222", width:3, opacity:1 } },
      { selector:".pathNode",  style:{ "border-width":3, "border-color":"#222" } },
      { selector:"node.locked", style:{ "border-width":3, "border-color":"#000" } }
    ]
  });

  window.cy = cy; // 方便调试
  pinned.clear();
  pathLocked = false;
  selectedCluster = null;                 // 重绘清空簇选择

  cy.ready(() => { cy.fit(undefined, 60); renderHistory(); });

  /* ---------- 悬停：高亮 1 跳自我网络；移出恢复 ---------- */
  const ego1 = (node) => node.closedNeighborhood();  // 1-hop
  const pinnedNodesCol = () => cy.collection([...pinned].map(id => cy.getElementById(id)));
  const pinnedEdgesCol = () => cy.edges().filter(e => pinned.has(e.data("source")) && pinned.has(e.data("target")));

  const applyPinned = () => {
    cy.elements().removeClass("faded highlight pathEdge pathNode");
    if (pinned.size === 0) return;
    const pinNodes = pinnedNodesCol();
    const pinEdges = pinnedEdgesCol();
    cy.elements().addClass("faded");
    pinNodes.removeClass("faded").addClass("highlight");
    pinEdges.removeClass("faded").addClass("highlight");
  };
  applyPinnedExternal = applyPinned;

  cy.on("mouseover", "node", e => {
    if (collapsed || pathLocked) return;
    const sub = ego1(e.target);
    let keep = sub.union(pinnedNodesCol()).union(pinnedEdgesCol());
    cy.elements().addClass("faded");
    keep.removeClass("faded").addClass("highlight");
  });

  cy.on("mouseout", "node", () => {
    // 折叠视图且选中过簇时，保持 meta-node 高亮
    if (collapsed && selectedCluster != null) return;
    if (pathLocked) return;
    applyPinned();
  });

  /* ---------- 点击：节点 or 簇 ---------- */
  cy.on("tap", "node", e => {
    if (pathLocked) return;

    // 折叠视图：点击 meta-node（cluster:x）保持高亮并刷新摘要
    if (collapsed && String(e.target.id()).startsWith("cluster:")) {
      const cid = e.target.data("cluster");
      selectedCluster = cid;
      showClusterSummary(cid);
      cy.elements().removeClass("faded highlight pathEdge pathNode");
      cy.elements().addClass("faded");
      e.target.removeClass("faded").addClass("highlight");
      return;
    }

    // 普通节点
    const n = e.target;
    const id = n.id();
    selectedCluster = null; // 退出簇选中态

    const isNeighborOfPinned =
      pinned.size>0 && n.connectedEdges().some(ed => {
        const a = ed.data("source"), b = ed.data("target");
        return pinned.has(a) || pinned.has(b);
      });

    if (pinned.size === 0) pinned.add(id);
    else if (isNeighborOfPinned) pinned.add(id);
    else { pinned.clear(); pinned.add(id); }

    // A/B 收集（最短路）
    lastPicked.push(n);
    if (lastPicked.length > 2) lastPicked.shift();

    // 侧栏写节点信息
    const d   = n.data();
    const txt =
      `ID    : ${d.id}\n` +
      (d.title ?  `Title : ${d.title}\n` : "") +
      (d.label ?  `Label : ${d.label}\n` : "") +
      (d.topic ?  `Topic : ${d.topic}\n` : "") +
      (d.year  ?  `Year  : ${d.year}\n`  : "");
    document.getElementById("info").textContent = txt;

    addToHistory(d);         // ★ 记录历史
    applyPinned();
  });

  /* 点击空白：清除高亮，回到总览 */
  cy.on("tap", e => {
    if (e.target !== cy) return;
    pinned.clear();
    pathLocked = false;
    selectedCluster = null;
    cy.elements().removeClass("faded highlight pathEdge pathNode");
    showClusterSummary();
  });

  // 初始填充簇摘要
  showClusterSummary();

  /* 图例点击：未折叠→高亮整簇；折叠→高亮 meta 并保持 */
  wireLegendClicks(applyPinned);
}

/* ---------- 簇摘要渲染 ---------- */
function showClusterSummary(cid = null) {
  const box = document.getElementById("clusterSummary");
  const rel = document.getElementById("relation").value;

  if (!clusterIndex) { box.textContent = "—"; return; }

  if (cid == null) {
    const k = new Set(originalGraph.nodes.map(n=>n.cluster)).size;
    box.textContent =
      `Relation : ${rel}\n` +
      `Clusters : ${k}\n` +
      `Hint     : Click a legend item to drill down into a cluster.`;
    return;
  }

  const rec = clusterIndex.get(cid);
  if (!rec) { box.textContent = "—"; return; }

  box.textContent =
    `Cluster  : ${cid}\n` +
    `Size     : ${rec.size}\n` +
    `Edges    : intra=${rec.intra}, in=${rec.in}, out=${rec.out}\n` +
    `Topics   : ${rec.topics.join(", ")}\n` +
    `Keywords : ${rec.topTerms.join(", ")}\n` +
    `Sample   :\n` +
    rec.nodes.slice(0,3).map(n=>"  - "+(n.title||n.label||n.id)).join("\n");
}

/* ---------- 4. 侧栏：统计 + 图例 ---------- */
function updateSidebar(stats, graph) {
  document.getElementById("stats").textContent =
      `Nodes   : ${stats.nodes}\n` +
      `Edges   : ${stats.edges}\n` +
      `Clusters: ${new Set(graph.nodes.map(n=>n.cluster)).size}`;

  const legend   = document.getElementById("legend");
  legend.innerHTML = "";
  const clusterIds = [...new Set(graph.nodes.map(n=>n.cluster))].sort();

  clusterIds.forEach(c => {
    const exNode = graph.nodes.find(n => n.cluster === c) || {};
    const nice   = exNode.topic || exNode.label || `Cluster ${c}`;
    const div = document.createElement("div");
    div.dataset.cluster = String(c);
    div.innerHTML =
      `<span style="background:${colorByCluster(c)}"></span>${nice}`;
    legend.appendChild(div);
  });
}

/* 图例点击（不重绘，不闪屏） */
function wireLegendClicks(applyPinned) {
  const legend = document.getElementById("legend");
  legend.onclick = (e) => {
    const div = e.target.closest("div[data-cluster]");
    if (!div) return;
    const c = Number(div.dataset.cluster);
    showClusterSummary(c);

    if (!cy) return;
    if (!document.getElementById("chkCollapse").checked) {
      pinned.clear();
      cy.nodes().forEach(n => { if (n.data("cluster") === c) pinned.add(n.id()); });
      pathLocked = false;
      applyPinned();
      return;
    }
    // 折叠模式：高亮 meta 并保持
    selectedCluster = c;
    cy.elements().removeClass("faded highlight");
    const meta = cy.getElementById(`cluster:${c}`);
    if (meta.nonempty()) {
      cy.elements().addClass("faded");
      meta.removeClass("faded").addClass("highlight");
    }
  };
}

/* ---------- 折叠/展开：单簇切换（仅在“折叠模式”下生效） ---------- */
function toggleOneCluster(c) {
  if (!cy) return;
  if (!document.getElementById("chkCollapse").checked) return;
  const rel = document.getElementById("relation").value;
  collapsed = !collapsed;
  collapsed = true;
  draw(originalGraph, rel);
}

/* ---------- 关系/布局/折叠 切换 ---------- */
document.getElementById("layout").onchange = () => {
  if (!cy) return;
  cy.layout( getLayoutOpts(document.getElementById("layout").value) ).run();
};
document.getElementById("relation").onchange = () => {
  if (!originalGraph) return;
  draw(originalGraph, document.getElementById("relation").value);
  updateSidebar({nodes:originalGraph.nodes.length, edges:originalGraph.edges.length}, originalGraph);
};
document.getElementById("chkCollapse").onchange = () => {
  if (!originalGraph) return;
  draw(originalGraph, document.getElementById("relation").value);
};

/* ---------- 6. Upload & Draw ---------- */
document.getElementById("btn").onclick = async () => {
  const file = document.getElementById("uploader").files[0];
  if (!file) { alert("Please select a JSON file first!"); return; }
  try {
    const task_id = await upload(file);
    const [graph, stats] = await Promise.all([ fetchGraph(task_id), fetchStats(task_id) ]);
    draw(graph, document.getElementById("relation").value);
    updateSidebar(stats, graph);
    setupTimeline(graph);
  } catch (err) {
    console.error("Upload/Draw error:", err); // 以后可直接从控制台看到具体错误
    alert("An error occurred during upload or rendering!");
  }
};

/* ---------- 5. 最短路 ---------- */
document.getElementById("btnPath").onclick = () => {
  if (!cy) return;
  cy.elements().removeClass("pathEdge pathNode");

  if (lastPicked.length < 2) { alert("Pick two nodes (click) first."); return; }
  const [a,b] = lastPicked;

  const dj = cy.elements().dijkstra({ root:a, weight: e => 1 });
  const dist = dj.distanceTo(b);

  if (!isFinite(dist)) { alert("No citation path between the two nodes."); return; }

  const path = dj.pathTo(b);
  cy.elements().addClass("faded");
  path.removeClass("faded");
  path.nodes().addClass("pathNode");
  path.edges().addClass("pathEdge");
  pathLocked = true;   // 锁定
};

/* ---------- 时间轴：按年份过滤 ---------- */
function setupTimeline(graph) {
  const box = document.getElementById("timeBox");
  const slider = document.getElementById("yearSlider");
  const label  = document.getElementById("yearLabel");
  const years = graph.nodes.map(n=>n.year).filter(y=>y!=null);
  if (!years.length) { box.style.display="none"; return; }
  box.style.display="";
  const minY = Math.min(...years), maxY = Math.max(...years);
  slider.min = String(minY); slider.max = String(maxY); slider.value = String(maxY);
  label.textContent = maxY;

  const apply = () => {
    const y = +slider.value; label.textContent = y;
    cy.batch(()=>{
      cy.nodes().forEach(n=>{
        const yy = n.data("year");
        n.style("display", (yy==null || yy<=y) ? "element" : "none");
      });
      cy.edges().forEach(e=>{
        const s = cy.getElementById(e.data("source"));
        const t = cy.getElementById(e.data("target"));
        const vis = (s.nonempty() && s.style("display")!=="none") &&
                    (t.nonempty() && t.style("display")!=="none");
        e.style("display", vis ? "element" : "none");
      });
    });
  };
  slider.oninput = apply;
  apply();
}

/* ---------- TODO（可选扩展） ----------
 * 7) 边捆绑：cytoscape.js-edge-bundling
 * 8) 语义搜索 / 相似推荐（/api/nn）
 */












