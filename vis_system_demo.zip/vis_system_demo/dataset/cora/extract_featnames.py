import numpy as np

# 1. 读取 graph2gauss 的压缩文件
data = np.load("cora_ml.npz", allow_pickle=True)

# 2. 取出 attr_names（1433 个单词）
feat_names = data["attr_names"]           # numpy.ndarray

# 3. 写成纯文本  (index<tab>word)
with open("cora.featnames", "w", encoding="utf-8") as f:
    for i, w in enumerate(feat_names):
        f.write(f"{i}\t{w}\n")

print("✔ 词典已写入 cora.featnames ")
