#!/usr/bin/env python
# dataset/cora/convert_cora.py
import json, pathlib, csv

ROOT   = pathlib.Path(__file__).parent
CITES  = ROOT/'cora.cites'
CONTENT= ROOT/'cora.content'
OUT    = ROOT.parent.parent/'samples'/'cora_full.json'   # …/samples/cora_full.json

# ------------ 1. 解析 .content ------------
label2id = {}                       # 把 7 个文本标签映射到 0‑6
nodes    = []

with CONTENT.open() as f:
    for line in f:
        parts = line.strip().split()
        paper_id = parts[0]                     # string
        class_lbl= parts[-1]                    # text label
        cid = label2id.setdefault(class_lbl, len(label2id))
        nodes.append({"id": paper_id,
                      "label": paper_id,        # 先用 paper_id 当可视标签
                      "cluster": cid})

# ------------ 2. 解析 .cites ------------
edges = []
with CITES.open() as f:
    rdr = csv.reader(f, delimiter='\t')
    for src, dst in rdr:                        # 每行: cited  citing
        edges.append({"source": dst, "target": src})  # 无向 -> 任选方向即可

print(f"Nodes: {len(nodes)},  Edges: {len(edges)},  Clusters: {len(label2id)}")

# ------------ 3. 写出 JSON ------------
OUT.parent.mkdir(parents=True, exist_ok=True)
with OUT.open('w', encoding='utf-8') as f:
    json.dump({"nodes": nodes, "edges": edges}, f)

print("✓  Saved  →", OUT)
