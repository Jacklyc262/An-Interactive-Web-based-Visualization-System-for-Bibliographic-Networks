#!/usr/bin/env python
# convert_cora_500.py  ──  keep 500 nodes → samples/cora500.json
# --------------------------------------------------------------
import pathlib, json, csv

# ─── 路径常量 ───────────────────────────────────────────────────
ROOT    = pathlib.Path(__file__).parent          # dataset/cora/
CITES   = ROOT / 'cora.cites'
CONTENT = ROOT / 'cora.content'
OUT     = ROOT.parent.parent / 'samples' / 'cora500.json'

# ─── 1. 读取内容文件（节点） ──────────────────────────────────
nodes, id_set = [], set()
with CONTENT.open() as f:
    rdr = csv.reader(f, delimiter='\t')
    for i, row in enumerate(rdr):
        pid, *_, label = row
        nodes.append({'id': pid, 'label': label})
        id_set.add(pid)
        if i == 499:        # 只保留前 500 行（索引 0‑499）
            break

# ─── 2. 读取引用文件（边） ──────────────────────────────────
edges = []
with CITES.open() as f:
    rdr = csv.reader(f, delimiter='\t')
    for src, tgt in rdr:
        # 只保留两端都在 500 节点集合里的边
        if src in id_set and tgt in id_set:
            edges.append({'source': src, 'target': tgt})

# ─── 3. 输出 JSON ────────────────────────────────────────────
OUT.parent.mkdir(parents=True, exist_ok=True)
with OUT.open('w', encoding='utf‑8') as f:
    json.dump({'nodes': nodes, 'edges': edges}, f, ensure_ascii=False)

print(f"  Nodes kept: {len(nodes):4d}   Edges kept: {len(edges):5d}")
print("  Saved →", OUT.relative_to(pathlib.Path.cwd()))
