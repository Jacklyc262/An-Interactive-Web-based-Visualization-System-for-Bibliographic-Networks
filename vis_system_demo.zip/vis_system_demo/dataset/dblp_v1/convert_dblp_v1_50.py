# ----------------------------------------------------------
#  convert_dblp_v1_50.py   抽取 DBLP Citation-network V1
#  只保留前 50 篇论文 + 内部引用，输出 samples/dblp_v1_50.json
# ----------------------------------------------------------
import pathlib, json

ROOT       = pathlib.Path(__file__).parent           # dataset/dblp_v1
RAW_TXT    = ROOT / "citation-network1.txt"          # 解压后的原始大文本
OUT_JSON   = ROOT.parent.parent / "samples" / "dblp_v1_50.json"

nodes, id_set, tmp_edges = [], set(), []
paper = {}

def flush_paper():
    """把当前 paper 写进 nodes／临时边列表（限前 50 篇）"""
    # 若还没解析出 id，或已经够 50 篇，就返回
    if ("id" not in paper) or len(nodes) >= 50:
        return
    # ★ title & label 都写；label 先留空串（后端可再处理）
    nodes.append({
        "id"   : paper["id"],
        "title": paper["title"],
        "label": ""               # 目前暂无类别
    })
    id_set.add(paper["id"])
    tmp_edges.extend((paper["id"], r) for r in paper["refs"])

with RAW_TXT.open(encoding="utf-8", errors="ignore") as f:
    for line in f:
        if line.startswith("#index"):                # ---- 新论文开始
            flush_paper()
            if len(nodes) >= 50:                     # 已够 50 篇
                break
            paper = {
                "id"   : line[6:].strip(),
                "title": "(no-title)",
                "refs" : []
            }

        elif line.startswith("#*"):                  # 题目
            paper["title"] = line[2:].strip() or "(no-title)"

        elif line.startswith("#%"):                  # 引用
            rid = line[2:].strip()
            if rid:
                paper["refs"].append(rid)

# 处理文件末尾最后一篇
flush_paper()

# ---- 只保留内部引用边 ----
edges = [
    {"source": s, "target": t}
    for s, t in tmp_edges
    if s in id_set and t in id_set
]

# ---- 输出 JSON ----
OUT_JSON.parent.mkdir(parents=True, exist_ok=True)
with OUT_JSON.open("w", encoding="utf-8") as f:
    json.dump({"nodes": nodes, "edges": edges},
              f, ensure_ascii=False, indent=2)

print(f"✓ 生成完成：{OUT_JSON}")
print(f"  Nodes : {len(nodes)}   Edges : {len(edges)}")
