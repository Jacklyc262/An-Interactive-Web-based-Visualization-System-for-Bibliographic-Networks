# ----------------------------------------------------------
#  convert_dblp_v1_100_dense.py
#  从 DBLP Citation-network V1 中挑选“互相尽量有引用”的 100 篇论文，
#  输出 samples/dblp_v1_100.json（含 id、title、内部引用边）。
#
#  算法（三步）：
#   1) 并查集合并所有引用关系，找出“最大连通分量”（只按 #index 真正存在的论文计数）
#   2) 只在该分量内重建邻接，选“分量内度数最高”的论文为种子做 BFS/扩张直到 100
#   3) 输出这 100 篇论文的子图（只保留内部边）
# ----------------------------------------------------------

import re
import json
import pathlib
from collections import defaultdict, Counter, deque

ROOT = pathlib.Path(__file__).parent                  # dataset/dblp_v1
# 兼容不同原始文件名（有人下载的是 citation-network1.txt，也有人是 outputacm.txt）
CANDIDATES = [
    ROOT / "citation-network1.txt",
    ROOT / "outputacm.txt",
    ROOT / "outputacm",
]
RAW_TXT = next((p for p in CANDIDATES if p.exists()), None)
if RAW_TXT is None:
    # 兜底：找目录下任意 .txt
    txts = list(ROOT.glob("*.txt"))
    if not txts:
        raise FileNotFoundError("未找到原始数据：请把 citation-network1.txt 或 outputacm.txt 放到 dataset/dblp_v1/")
    RAW_TXT = txts[0]

OUT_JSON = ROOT.parent.parent / "samples" / "dblp_v1_100.json"
TARGET_N = 100

# ---------- 简单 parser：逐篇产出 {id, title, refs[]} ----------
def parse_papers(path):
    paper = None
    with open(path, "r", encoding="utf-8", errors="ignore") as f:
        for line in f:
            if line.startswith("#index"):
                # flush
                if paper and "id" in paper:
                    yield paper
                pid = line[6:].strip()
                paper = {"id": pid, "title": "", "refs": []}
            elif line.startswith("#*") and paper is not None:
                paper["title"] = line[2:].strip()
            elif line.startswith("#%") and paper is not None:
                rid = line[2:].strip()
                if rid:
                    paper["refs"].append(rid)
        # last one
        if paper and "id" in paper:
            yield paper

# ---------- 并查集 ----------
class DSU:
    def __init__(self):
        self.parent = {}
        self.rank = {}

    def add(self, x):
        if x not in self.parent:
            self.parent[x] = x
            self.rank[x] = 0

    def find(self, x):
        # 路径压缩
        px = self.parent.get(x, x)
        if px != x:
            self.parent[x] = self.find(px)
        return self.parent.get(x, x)

    def union(self, a, b):
        ra, rb = self.find(a), self.find(b)
        if ra == rb:
            return
        # 按秩合并
        if self.rank[ra] < self.rank[rb]:
            ra, rb = rb, ra
        self.parent[rb] = ra
        if self.rank[ra] == self.rank[rb]:
            self.rank[ra] += 1

# ---------- Pass-1：连通分量（只统计真正有 #index 的论文） ----------
def build_components():
    dsu = DSU()
    indexed = set()             # 真的有 #index 的论文
    print("Pass-1: 扫描全库，合并引用关系（并查集）...")
    for p in parse_papers(RAW_TXT):
        pid = p["id"]
        dsu.add(pid)
        indexed.add(pid)
        # 与每个引用做 union（ref 可能没有 #index，但我们仍然并进去保持连通）
        for rid in p["refs"]:
            dsu.add(rid)
            dsu.union(pid, rid)

    # 只按“有 #index 的论文”统计分量大小
    root_count = Counter(dsu.find(x) for x in indexed)
    root_biggest, _ = root_count.most_common(1)[0]

    # 该最大分量中的“有 #index 的论文集合”
    comp_nodes = {x for x in indexed if dsu.find(x) == root_biggest}
    print(f"最大连通分量节点数（仅 #index）：{len(comp_nodes)}")
    return comp_nodes

# ---------- Pass-2：在最大分量内重建邻接，挑 100 个“边尽量多”的节点 ----------
def pick_dense_100(comp_nodes):
    print("Pass-2: 重建最大分量内的邻接，并挑选 100 个互相尽量有边的节点...")

    adj = defaultdict(set)    # 无向邻接，只在 comp_nodes 内连
    titles = {}               # id -> title（只保存分量内的）

    # 只在分量内累加边
    for p in parse_papers(RAW_TXT):
        pid = p["id"]
        if pid not in comp_nodes:
            continue
        titles[pid] = p["title"]
        for rid in p["refs"]:
            if rid in comp_nodes:
                # 视为无向近邻（利于 BFS 扩张“密集区域”）
                adj[pid].add(rid)
                adj[rid].add(pid)

    # 若极端稀疏，可能出现某些点度为 0，先选度最大者为种子
    if not adj:
        raise RuntimeError("最大分量内未能构建邻接（数据异常）。")

    # 选分量内度数最高的点为种子
    seed = max(adj.keys(), key=lambda x: len(adj[x]))
    print(f"种子节点：{seed}（度={len(adj[seed])}）")

    # BFS / 扩张，优先扩张高度邻居，尽量形成密集子图
    selected = []
    visited  = set([seed])
    # 队列里放 (当前节点, -度) 让高程度优先（也可以简单 deque）
    q = deque([seed])

    while q and len(selected) < TARGET_N:
        u = q.popleft()
        selected.append(u)
        # 邻居按度数降序扩张
        nbrs = sorted(adj[u], key=lambda v: len(adj[v]), reverse=True)
        for v in nbrs:
            if v not in visited:
                visited.add(v)
                q.append(v)
            if len(selected) >= TARGET_N:
                break

    # 若 BFS 不足 100（极端稀疏），用“分量内剩余度数最高”的补齐
    if len(selected) < TARGET_N:
        remaining = [n for n in adj.keys() if n not in visited]
        remaining.sort(key=lambda v: len(adj[v]), reverse=True)
        for v in remaining:
            selected.append(v)
            if len(selected) >= TARGET_N:
                break

    selected = selected[:TARGET_N]
    selected_set = set(selected)
    print(f"选取节点数：{len(selected)}")

    # 生成内部边（方向保持原始 #index -> #% 的方向）
    edges = []
    # 重新遍历一次（也可在上面顺手记录，这里保持清晰）
    for p in parse_papers(RAW_TXT):
        pid = p["id"]
        if pid not in selected_set:
            continue
        # 补全 title（如前面未记录）
        titles.setdefault(pid, p["title"])
        for rid in p["refs"]:
            if rid in selected_set:
                edges.append({"source": pid, "target": rid})

    nodes = [{"id": nid, "title": titles.get(nid, "")} for nid in selected]
    return nodes, edges

def main():
    comp_nodes = build_components()
    nodes, edges = pick_dense_100(comp_nodes)

    OUT_JSON.parent.mkdir(parents=True, exist_ok=True)
    with open(OUT_JSON, "w", encoding="utf-8") as f:
        json.dump({"nodes": nodes, "edges": edges}, f, ensure_ascii=False, indent=2)

    print(f"✓ {OUT_JSON}  已生成")
    print(f"  Nodes : {len(nodes)}   Edges : {len(edges)}")

if __name__ == "__main__":
    main()
