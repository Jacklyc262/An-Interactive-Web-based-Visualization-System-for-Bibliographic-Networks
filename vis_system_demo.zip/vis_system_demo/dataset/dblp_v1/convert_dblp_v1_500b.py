# ----------------------------------------------------------
#  convert_dblp_v1_500b.py
#  目标：从 DBLP Citation-network V1 的 citation-network1.txt
#       挑出“度数更均衡 + 整体更稠密”的 500 篇
#  方法：无向化 → 寻找最大 k-core(≥500) → 核心内 densest-subgraph 贪心
#  输出：samples/dblp_v1_500b.json
#  运行：直接 Run
# ----------------------------------------------------------

import json
import pathlib
from collections import defaultdict, deque

# --- 路径 ---
ROOT     = pathlib.Path(__file__).parent                # dataset/dblp_v1
RAW_TXT  = ROOT / "citation-network1.txt"               # 原始文本
OUT_JSON = ROOT.parent.parent / "samples" / "dblp_v1_500b.json"

TARGET_N = 500

# ========== 第 1 步：解析（与旧脚本一致） ==========
papers_title: dict[str, str] = {}
refs_out:     dict[str, list[str]] = defaultdict(list)   # 出边：id -> [refs...]
refs_in:      dict[str, list[str]] = defaultdict(list)   # 入边：rid -> [who cite it...]

cur_id = None
cur_title = "(no-title)"

def flush_current():
    """把当前论文的 title 写入字典（如果解析到 id 了）"""
    if cur_id is not None and cur_id not in papers_title:
        papers_title[cur_id] = cur_title or "(no-title)"

with RAW_TXT.open(encoding="utf-8", errors="ignore") as f:
    for line in f:
        if line.startswith("#index"):
            flush_current()
            cur_id = line[6:].strip()
            cur_title = "(no-title)"
        elif line.startswith("#*"):
            cur_title = line[2:].strip() or "(no-title)"
        elif line.startswith("#%"):
            rid = line[2:].strip()
            if cur_id and rid:
                refs_out[cur_id].append(rid)
                refs_in[rid].append(cur_id)
flush_current()

all_ids = set(papers_title.keys())

# ========== 第 2 步：构建“无向图”邻接（用于 k-core / 密度） ==========
# 规则：有任一方向引用就算一条无向边
adj: dict[str, set[str]] = {pid: set() for pid in all_ids}
for s, outs in refs_out.items():
    for t in outs:
        if s in all_ids and t in all_ids and s != t:
            adj[s].add(t)
            adj[t].add(s)

# 可选：只取最大连通分量（弱连通），避免碎片影响
def largest_component(nodes: set[str]) -> set[str]:
    seen = set()
    best_comp = set()
    for v in nodes:
        if v in seen: continue
        comp = set()
        dq = deque([v]); seen.add(v)
        while dq:
            x = dq.popleft()
            comp.add(x)
            for nb in adj.get(x, ()):
                if nb not in seen:
                    seen.add(nb); dq.append(nb)
        if len(comp) > len(best_comp):
            best_comp = comp
    return best_comp

giant = largest_component(set(adj.keys()))

# ========== 第 3 步：找最大 k-core（规模 ≥ 500） ==========
def k_core_nodes(nodes: set[str], k: int) -> set[str]:
    """从 nodes 诱导子图中迭代剥离度<k 的点，返回剩余节点集"""
    from collections import deque
    deg = {u: len(adj[u] & nodes) for u in nodes}
    q = deque([u for u in nodes if deg[u] < k])
    alive = set(nodes)
    while q:
        u = q.popleft()
        if u not in alive: continue
        alive.remove(u)
        for v in adj[u]:
            if v in alive:
                deg[v] -= 1
                if deg[v] < k:
                    q.append(v)
    return alive

def max_kcore_with_at_least(nodes: set[str], at_least: int) -> tuple[int, set[str]]:
    """从 1..Δ 二分/线性找满足规模≥at_least 的最大 k-core"""
    if not nodes: return 0, set()
    max_deg = max(len(adj[u] & nodes) for u in nodes)
    lo, hi = 0, max_deg
    best_k, best_set = 0, set(nodes)
    while lo <= hi:
        mid = (lo + hi) // 2
        core = k_core_nodes(nodes, mid)
        if len(core) >= at_least:
            best_k, best_set = mid, core
            lo = mid + 1
        else:
            hi = mid - 1
    return best_k, best_set

k_best, core_nodes = max_kcore_with_at_least(giant, TARGET_N)

# 如果最大 k-core 也达不到 500，就对 giant 做 densest
base_nodes = core_nodes if len(core_nodes) >= TARGET_N else giant

# ========== 第 4 步：densest-subgraph 贪心剥皮（Charikar） ==========
def densest_greedy(nodes: set[str]) -> list[str]:
    """
    返回密度峰值对应的节点列表（尽可能稠密）。
    如果过程记录多个快照，这里取 2m/n 最大的那次。
    """
    # 工作副本
    cur = set(nodes)
    deg = {u: len(adj[u] & cur) for u in cur}
    import heapq
    heap = [(deg[u], u) for u in cur]
    heapq.heapify(heap)

    # 记录密度最佳快照
    m = sum(deg[u] for u in cur) // 2  # 无向边数
    best_density = (2 * m) / max(1, len(cur))
    best_snapshot = list(cur)

    removed = set()
    while heap and cur:
        # 取出堆顶（可能是陈旧度，需跳过）
        d, u = heapq.heappop(heap)
        if u in removed or u not in cur or d != deg[u]:
            continue
        # 删 u
        cur.remove(u)
        removed.add(u)
        for v in adj[u]:
            if v in cur:
                deg[v] -= 1
                heapq.heappush(heap, (deg[v], v))
        # 更新当前密度
        # 边数减少了 d
        m -= d
        if cur:
            dens = (2 * m) / len(cur)
            if dens > best_density:
                best_density = dens
                best_snapshot = list(cur)

    return best_snapshot

dense_nodes = set(densest_greedy(base_nodes))

# 若密度峰值集仍 < 500，则在 base_nodes 内按度数高的补齐；若 > 500，则按内部度最小的裁剪到 500
def internal_degree(u: str, S: set[str]) -> int:
    return len(adj[u] & S)

picked = set(dense_nodes)
if len(picked) < TARGET_N:
    # 从 base_nodes - picked 中，按对 (picked ∪ {候选}) 的边数最多优先补齐
    candidates = sorted((base_nodes - picked), key=lambda x: internal_degree(x, base_nodes), reverse=True)
    for x in candidates:
        picked.add(x)
        if len(picked) >= TARGET_N: break
elif len(picked) > TARGET_N:
    # 在 picked 内部，迭代删除内部度最小的，直至 500
    # 为了稳定性用简单循环（500 规模足够快）
    while len(picked) > TARGET_N:
        # 计算每个点在 picked 里的内部度
        victim = min(picked, key=lambda x: internal_degree(x, picked))
        picked.remove(victim)

# 万一还不够（极端情况下），再从 giant 里按度数补
if len(picked) < TARGET_N:
    leftovers = sorted((giant - picked), key=lambda x: len(adj[x] & giant), reverse=True)
    for x in leftovers:
        picked.add(x)
        if len(picked) >= TARGET_N: break

picked = set(list(picked)[:TARGET_N])  # 再保险截断

# ========== 第 5 步：只保留内部“有向边”（用于前端 citation 视角） ==========
edges = []
for s in picked:
    for t in refs_out.get(s, []):
        if t in picked:
            edges.append({"source": s, "target": t})

# ========== 第 6 步：写 JSON（label 置空，title 保留） ==========
nodes = [{
    "id": pid,
    "title": papers_title.get(pid, "(no-title)"),
    "label": ""                    # 让前端用 topic 作为“聚类标签”
} for pid in sorted(picked)]        # 稳定顺序

OUT_JSON.parent.mkdir(parents=True, exist_ok=True)
with OUT_JSON.open("w", encoding="utf-8") as f:
    json.dump({"nodes": nodes, "edges": edges}, f, ensure_ascii=False, indent=2)

print(f"✓ 生成完成：{OUT_JSON}")
print(f"  Nodes : {len(nodes)}   Edges : {len(edges)}")
print(f"  k-core k* = {k_best}, |core| = {len(core_nodes)} ; base = {'core' if len(core_nodes)>=TARGET_N else 'giant'}")
