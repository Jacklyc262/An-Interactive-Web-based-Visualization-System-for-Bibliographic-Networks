# ----------------------------------------------------------
#  convert_dblp_v1_500a.py
#  从 DBLP Citation-network V1 的 outputacm.txt 中抽取「尽量连通」的 500 篇
#  输出：samples/dblp_v1_500.json
#  运行方式：直接在 PyCharm 里 Run 这个文件即可
# ----------------------------------------------------------

import json
import pathlib
from collections import defaultdict, deque

# --- 路径写死 ---
ROOT     = pathlib.Path(__file__).parent               # dataset/dblp_v1
RAW_TXT  = ROOT / "citation-network1.txt"             # 解压后的原始文本
OUT_JSON = ROOT.parent.parent / "samples" / "dblp_v1_500a.json"

TARGET_N = 500  # ← 写死 500

# ------- 第 1 步：解析原始文件，得到 id -> title / refs -------
papers_title: dict[str, str] = {}
refs_out:     dict[str, list[str]] = defaultdict(list)   # 出边：id -> [refs...]
refs_in:      dict[str, list[str]] = defaultdict(list)   # 入边：rid -> [who cite it...]

cur_id = None
cur_title = "(no-title)"

def flush_current():
    """把当前论文的 title 写入字典（如果解析到 id 了）"""
    if cur_id is not None and cur_id not in papers_title:
        papers_title[cur_id] = cur_title or "(no-title)"

with RAW_TXT.open(encoding="utf-8", errors="ignore") as f:
    for line in f:
        if line.startswith("#index"):
            # 遇到新论文，先刷掉上一篇
            flush_current()
            cur_id = line[6:].strip()
            cur_title = "(no-title)"
        elif line.startswith("#*"):
            cur_title = line[2:].strip() or "(no-title)"
        elif line.startswith("#%"):
            rid = line[2:].strip()
            if cur_id and rid:
                refs_out[cur_id].append(rid)
                refs_in[rid].append(cur_id)

# 文件结束后再刷一次
flush_current()

all_ids = set(papers_title.keys())

# ------- 第 2 步：选一个“最有连接”的种子，做 BFS 扩展到 500 -------
def inner_degree(pid: str) -> int:
    """近似‘强连接度’：出度 + 入度（只统计落在全集中的）"""
    return len([r for r in refs_out.get(pid, []) if r in all_ids]) + \
           len([s for s in refs_in.get(pid, []) if s in all_ids])

# 选出度/入度最高的作为第一个种子
seed = max(all_ids, key=inner_degree) if all_ids else None

picked: set[str] = set()
queue  = deque()

def push_neighbors(x: str):
    """把 x 的邻居（出+入）都入队"""
    for nb in refs_out.get(x, []):
        if nb in all_ids and nb not in picked:
            queue.append(nb)
    for nb in refs_in.get(x, []):
        if nb in all_ids and nb not in picked:
            queue.append(nb)

if seed:
    picked.add(seed)
    push_neighbors(seed)

# BFS 扩展
while len(picked) < TARGET_N and queue:
    v = queue.popleft()
    if v in picked:
        continue
    picked.add(v)
    push_neighbors(v)

# 若 BFS 仍不足 500，则按度数高低继续补
if len(picked) < TARGET_N:
    remaining = [x for x in sorted(all_ids, key=inner_degree, reverse=True) if x not in picked]
    for x in remaining:
        picked.add(x)
        if len(picked) >= TARGET_N:
            break

picked = set(list(picked)[:TARGET_N])  # 保底截断

# ------- 第 3 步：只保留内部边 -------
edges = []
for s in picked:
    for t in refs_out.get(s, []):
        if t in picked:
            edges.append({"source": s, "target": t})

# ------- 第 4 步：写 JSON（节点含 id / title / label） -------
# 注意：label 故意留空，让前端/下游把 “topic（3个关键词）” 作为聚类标签来展示
nodes = [{
    "id": pid,
    "title": papers_title.get(pid, "(no-title)"),
    "label": ""                   # ← 关键修改：不再把 title 复制到 label
} for pid in sorted(picked)]       # 稳定输出顺序，便于版本控制

OUT_JSON.parent.mkdir(parents=True, exist_ok=True)
with OUT_JSON.open("w", encoding="utf-8") as f:
    json.dump({"nodes": nodes, "edges": edges}, f, ensure_ascii=False, indent=2)

print(f"✓ 生成完成：{OUT_JSON}")
print(f"  Nodes : {len(nodes)}   Edges : {len(edges)}")

