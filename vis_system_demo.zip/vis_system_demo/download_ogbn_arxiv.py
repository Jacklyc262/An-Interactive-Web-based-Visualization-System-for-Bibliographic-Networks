#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
download_ogbn_arxiv.py
把 ogbn-arXiv 数据集下载到本地，并打印节点/边统计信息
"""

import os
from ogb.nodeproppred import NodePropPredDataset

# --- 1. 想放到哪儿就写哪儿 ----------------------------------------------
ROOT = os.path.join(os.path.dirname(__file__), "dataset", "ogbn_arxiv")
# ---------------------------------------------------------------------------

print(f"◎ 下载目录: {ROOT}（不存在会自动创建）")

ds = NodePropPredDataset(name="ogbn-arxiv", root=ROOT)  # 第一次会联网

graph, labels = ds[0]                     # graph 是 dict，labels 是 ndarray

print("✓ 下载&处理完毕")
print(f"  • 节点数: {graph['num_nodes']}")
print(f"  • 边数  : {graph['edge_index'].shape[1]}")
print(f"  • 特征维: {graph['node_feat'].shape[1]}")
print(f"  • 类别数: {labels.max()+1}")
